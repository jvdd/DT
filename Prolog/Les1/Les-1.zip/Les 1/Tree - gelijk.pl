gelijk(leeg,leeg).

gelijk(node(T1,T2,W1), node(T3,T4,W2)):-
	W1 = W2,
	gelijk(T1,T3),
	gelijk(T2,T4).