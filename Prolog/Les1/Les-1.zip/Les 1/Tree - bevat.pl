bevat(node(A,B,W1),W2):-
	W1 = W2;
	bevat(A,W2);
	bevat(B,W2).